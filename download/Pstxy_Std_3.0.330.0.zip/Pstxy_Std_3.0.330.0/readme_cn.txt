感谢您使用Pstxy. 这是一个纯.Net实现的Outlook .pst和.ost文件读取组件.
该版本是standard版, 只支持邮件正文的读取.

如果您对其他内容的读取, 比如附件, 联系人, 便签...感兴趣, 请考虑 (收费的) plus版本.
咨询购买请联系:  PantileSoft@outlook.com (https://pantilesoft.github.io/)