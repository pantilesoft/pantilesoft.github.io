Thank you for using Pstxy. It is a .NET implementation of Outlook .pst and .ost file reader.
This is the standard version, which extracts mail content only.

If you are interested in other types of content such as attachment, contact, note..., there's a (charged) plus version for you.
Please contact: PantileSoft@outlook.com (https://pantilesoft.github.io/)